# Minimum Reproducibility Dataset

This folder contains the minimum numerical dataset required to reproduce the reported simulation results for the manuscript:

**A Structured Neural-Supervised Fuzzy--PID Steering Controller with ISS Guarantees for Nonlinear Ackermann Vehicles**

## Contents

```text
data/
├── nominal_PID.csv
├── nominal_Fuzzy_PID.csv
├── nominal_NN_Fuzzy_PID.csv
├── nominal_MPC.csv
├── crosswind_PID.csv
├── crosswind_Fuzzy_PID.csv
├── crosswind_NN_Fuzzy_PID.csv
├── crosswind_MPC.csv
├── low_friction_*.csv
├── speed_mass_*.csv
├── noise_*.csv
└── parameter_variation_*.csv

config/
├── vehicle_parameters.json
├── controller_parameters.json
├── simulation_parameters.json
├── mpc_parameters.json
├── simulation_scenarios.json
└── disturbance_profiles.json

results/tables/
├── overall_metrics.csv
└── overall_metrics.xlsx
```

## CSV column description

Each CSV file contains time-series simulation data with the following key variables:

- `t`: simulation time (s)
- `x`, `y`: vehicle position (m)
- `psi`: yaw angle (rad)
- `vy`: lateral velocity (m/s)
- `r`: yaw rate (rad/s)
- `v`: longitudinal speed (m/s)
- `x_ref`, `y_ref`, `psi_ref`, `r_ref`, `v_ref`: reference trajectory variables
- `ey`: lateral tracking error (m)
- `epsi`: heading error (rad)
- `er`: yaw-rate tracking error (rad/s)
- `delta_rad`: steering command (rad)
- `delta_deg`: steering command (deg)
- `delta_rate_deg_s`: steering rate (deg/s)
- `Kp`, `Ki`, `Kd`: projected PID gains
- `dKpN`, `dKiN`, `dKdN`: neural gain corrections
- `dKpF`, `dKiF`, `dKdF`: fuzzy gain corrections
- `crosswind_N`: applied crosswind disturbance
- `mu`: tyre-road friction coefficient
- `mass_kg`: vehicle mass
- `Cf`, `Cr`: front and rear cornering stiffness

## Number of CSV files

Generated CSV files: 36

## Note

The dataset was generated using the Python reproducibility code. The high-fidelity MATLAB/Simulink and Simscape Multibody files may be provided separately subject to software-license and institutional constraints.
