import numpy as np
from .parameters import ControllerParams, VehicleParams
from .fuzzy_rules import fuzzy_gain_corrections

def sat(x, xmin, xmax):
    return float(np.clip(x, xmin, xmax))

class BaseController:
    def reset(self):
        pass

    def compute(self, ey, epsi, er, vy, r, v, Ts, vehicle_params):
        raise NotImplementedError

class PIDController(BaseController):
    def __init__(self, cp: ControllerParams):
        self.cp = cp
        self.reset()

    def reset(self):
        self.I = 0.0
        self.prev_s = 0.0
        self.dsf = 0.0
        self.prev_delta = 0.0

    def _error(self, ey, epsi, er):
        return self.cp.ky * ey + self.cp.kpsi * epsi + self.cp.kr * er

    def _filtered_derivative(self, s, Ts):
        raw = (s - self.prev_s) / Ts
        a = Ts / (self.cp.derivative_filter_tau + Ts)
        self.dsf = (1 - a) * self.dsf + a * raw
        self.prev_s = s
        return self.dsf

    def _limit_delta(self, delta, Ts, vehicle_params: VehicleParams):
        dmax = vehicle_params.delta_rate_max * Ts
        delta = sat(delta, self.prev_delta - dmax, self.prev_delta + dmax)
        delta = sat(delta, -vehicle_params.delta_max, vehicle_params.delta_max)
        self.prev_delta = delta
        return delta

    def compute(self, ey, epsi, er, vy, r, v, Ts, vehicle_params):
        s = self._error(ey, epsi, er)
        ds = self._filtered_derivative(s, Ts)
        self.I = sat(self.I + Ts * s, -self.cp.I_max, self.cp.I_max)
        delta = self.cp.Kp0 * s + self.cp.Ki0 * self.I + self.cp.Kd0 * ds
        return self._limit_delta(delta, Ts, vehicle_params), {
            "s": s, "ds": ds,
            "Kp": self.cp.Kp0, "Ki": self.cp.Ki0, "Kd": self.cp.Kd0
        }

class FuzzyPIDController(PIDController):
    def compute(self, ey, epsi, er, vy, r, v, Ts, vehicle_params):
        s = self._error(ey, epsi, er)
        ds = self._filtered_derivative(s, Ts)
        self.I = sat(self.I + Ts * s, -self.cp.I_max, self.cp.I_max)

        sn = sat(self.cp.Gs * s, -1.0, 1.0)
        dsn = sat(self.cp.Gsdot * ds, -1.0, 1.0)
        fkp, fki, fkd = fuzzy_gain_corrections(sn, dsn)

        Kp = sat(self.cp.Kp0 + self.cp.GKp * fkp, self.cp.Kp_min, self.cp.Kp_max)
        Ki = sat(self.cp.Ki0 + self.cp.GKi * fki, self.cp.Ki_min, self.cp.Ki_max)
        Kd = sat(self.cp.Kd0 + self.cp.GKd * fkd, self.cp.Kd_min, self.cp.Kd_max)

        delta = Kp * s + Ki * self.I + Kd * ds
        return self._limit_delta(delta, Ts, vehicle_params), {
            "s": s, "ds": ds, "Kp": Kp, "Ki": Ki, "Kd": Kd,
            "dKpF": self.cp.GKp * fkp, "dKiF": self.cp.GKi * fki, "dKdF": self.cp.GKd * fkd
        }

class NNFuzzyPIDController(FuzzyPIDController):
    def __init__(self, cp: ControllerParams, seed=7):
        self.rng = np.random.default_rng(seed)
        super().__init__(cp)

    def reset(self):
        super().reset()
        q = self.cp.hidden_neurons
        self.V = self.rng.uniform(-0.15, 0.15, size=(q, 5))
        self.bp = self.rng.uniform(-0.05, 0.05, size=q)
        self.Wp = self.rng.uniform(-0.03, 0.03, size=q)
        self.Wi = self.rng.uniform(-0.01, 0.01, size=q)
        self.Wd = self.rng.uniform(-0.02, 0.02, size=q)

    def _features(self, s, ds, vy, r, v):
        z = np.array([s, ds, vy, r, v], dtype=float)
        scale = np.array([1.0, 5.0, 3.0, 1.0, 25.0])
        zn = np.clip(z / scale, -2.0, 2.0)
        return np.tanh(self.V @ zn + self.bp)

    def compute(self, ey, epsi, er, vy, r, v, Ts, vehicle_params):
        s = self._error(ey, epsi, er)
        ds = self._filtered_derivative(s, Ts)
        self.I = sat(self.I + Ts * s, -self.cp.I_max, self.cp.I_max)

        sn = sat(self.cp.Gs * s, -1.0, 1.0)
        dsn = sat(self.cp.Gsdot * ds, -1.0, 1.0)
        fkp, fki, fkd = fuzzy_gain_corrections(sn, dsn)

        phi = self._features(s, ds, vy, r, v)

        dKpN = sat(float(self.Wp @ phi), -self.cp.KpN_max, self.cp.KpN_max)
        dKiN = sat(float(self.Wi @ phi), -self.cp.KiN_max, self.cp.KiN_max)
        dKdN = sat(float(self.Wd @ phi), -self.cp.KdN_max, self.cp.KdN_max)

        Kp = sat(self.cp.Kp0 + self.cp.GKp * fkp + dKpN, self.cp.Kp_min, self.cp.Kp_max)
        Ki = sat(self.cp.Ki0 + self.cp.GKi * fki + dKiN, self.cp.Ki_min, self.cp.Ki_max)
        Kd = sat(self.cp.Kd0 + self.cp.GKd * fkd + dKdN, self.cp.Kd_min, self.cp.Kd_max)

        delta = Kp * s + Ki * self.I + Kd * ds
        delta_c = self._limit_delta(delta, Ts, vehicle_params)

        # Sigma-modified bounded adaptation.
        self.Wp += Ts * (-self.cp.gamma_p * phi * s - self.cp.sigma_p * self.Wp)
        self.Wi += Ts * (-self.cp.gamma_i * phi * s - self.cp.sigma_i * self.Wi)
        self.Wd += Ts * (-self.cp.gamma_d * phi * s - self.cp.sigma_d * self.Wd)

        # Conservative weight clipping for implementation safety.
        self.Wp = np.clip(self.Wp, -0.5, 0.5)
        self.Wi = np.clip(self.Wi, -0.2, 0.2)
        self.Wd = np.clip(self.Wd, -0.3, 0.3)

        return delta_c, {
            "s": s, "ds": ds, "Kp": Kp, "Ki": Ki, "Kd": Kd,
            "dKpN": dKpN, "dKiN": dKiN, "dKdN": dKdN,
            "dKpF": self.cp.GKp * fkp, "dKiF": self.cp.GKi * fki, "dKdF": self.cp.GKd * fkd
        }
