import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

def savefig(path, dpi=300):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    plt.tight_layout()
    plt.savefig(path, dpi=dpi, bbox_inches="tight")
    plt.close()

def plot_path_comparison(data, scenario, outdir):
    plt.figure(figsize=(7.0, 4.2))
    first = True
    for (sc, ctrl), df in data.items():
        if sc != scenario:
            continue
        if first:
            plt.plot(df["x_ref"], df["y_ref"], "--", linewidth=2.0, label="Reference")
            first = False
        plt.plot(df["x"], df["y"], linewidth=1.8, label=ctrl)
    plt.xlabel("X position (m)")
    plt.ylabel("Y position (m)")
    plt.title(f"Path tracking comparison - {scenario}")
    plt.grid(True, linewidth=0.4)
    plt.legend()
    savefig(Path(outdir) / f"path_tracking_{scenario}.png", dpi=600)

def plot_lateral_error(data, scenario, outdir):
    plt.figure(figsize=(7.0, 4.2))
    for (sc, ctrl), df in data.items():
        if sc == scenario:
            plt.plot(df["t"], df["ey"], linewidth=1.8, label=ctrl)
    plt.xlabel("Time (s)")
    plt.ylabel("Lateral error (m)")
    plt.title(f"Lateral tracking error - {scenario}")
    plt.grid(True, linewidth=0.4)
    plt.legend()
    savefig(Path(outdir) / f"lateral_error_{scenario}.png", dpi=600)

def plot_steering(data, scenario, outdir):
    plt.figure(figsize=(7.0, 4.2))
    for (sc, ctrl), df in data.items():
        if sc == scenario:
            plt.plot(df["t"], df["delta_deg"], linewidth=1.6, label=ctrl)
    plt.xlabel("Time (s)")
    plt.ylabel("Steering angle (deg)")
    plt.title(f"Steering response - {scenario}")
    plt.grid(True, linewidth=0.4)
    plt.legend()
    savefig(Path(outdir) / f"steering_{scenario}.png", dpi=600)

def plot_gains(data, scenario, outdir):
    key = (scenario, "NN-Fuzzy-PID")
    if key not in data:
        return
    df = data[key]
    plt.figure(figsize=(7.0, 4.2))
    plt.plot(df["t"], df["Kp"], linewidth=1.8, label="$K_p$")
    plt.plot(df["t"], df["Ki"], linewidth=1.8, label="$K_i$")
    plt.plot(df["t"], df["Kd"], linewidth=1.8, label="$K_d$")
    plt.xlabel("Time (s)")
    plt.ylabel("Projected PID gains")
    plt.title(f"Adaptive gain evolution - {scenario}")
    plt.grid(True, linewidth=0.4)
    plt.legend()
    savefig(Path(outdir) / f"adaptive_gains_{scenario}.png", dpi=600)
