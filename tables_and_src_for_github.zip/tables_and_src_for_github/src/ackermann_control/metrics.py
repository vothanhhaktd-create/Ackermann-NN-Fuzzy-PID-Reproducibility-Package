import numpy as np
import pandas as pd

def rmse(x):
    x = np.asarray(x, dtype=float)
    return float(np.sqrt(np.mean(x**2)))

def compute_metrics(df):
    out = {}
    out["lateral_RMSE_m"] = rmse(df["ey"])
    out["peak_lateral_deviation_m"] = float(np.max(np.abs(df["ey"])))
    out["heading_RMSE_rad"] = rmse(df["epsi"])
    out["yaw_rate_RMSE_rad_s"] = rmse(df["er"])
    out["steering_RMS_deg_s"] = rmse(df["delta_rate_deg_s"])
    out["max_steering_deg"] = float(np.max(np.abs(df["delta_deg"])))
    out["velocity_RMSE_m_s"] = rmse(df["v"] - df["v_ref"])
    return out

def metrics_to_frame(metrics_dict):
    rows = []
    for key, value in metrics_dict.items():
        scenario, controller = key
        row = {"scenario": scenario, "controller": controller}
        row.update(value)
        rows.append(row)
    return pd.DataFrame(rows)
