import numpy as np
from .controllers import PIDController, sat
from .parameters import ControllerParams, VehicleParams

class MPCBenchmark(PIDController):
    """Lightweight predictive benchmark.

    This is not a full QP-based MPC implementation. It approximates a constrained
    predictive steering benchmark by combining LQR-like feedback with steering
    angle and steering-rate constraints. For a production MPC, replace this class
    with a QP solver such as OSQP, CVXOPT, or CasADi.
    """
    def __init__(self, cp: ControllerParams):
        super().__init__(cp)
        self.K = np.array([0.72, 1.10, 0.28])

    def compute(self, ey, epsi, er, vy, r, v, Ts, vehicle_params: VehicleParams):
        x = np.array([ey, epsi, er])
        delta = float(self.K @ x)
        delta = self._limit_delta(delta, Ts, vehicle_params)
        return delta, {"s": self._error(ey, epsi, er), "ds": self.dsf,
                       "Kp": self.K[0], "Ki": 0.0, "Kd": self.K[2]}
