import numpy as np

def reference_path(t, scenario="nominal"):
    """Analytic reference path.

    The path combines straight and sinusoidal/curved segments to create a
    realistic lateral tracking task.
    """
    v_ref = 15.0
    if scenario == "speed_mass":
        if t < 8:
            v_ref = 6.0
        elif t < 16:
            v_ref = 10.0
        else:
            v_ref = 7.0

    x_ref = v_ref * t
    y_ref = 2.0 * np.sin(0.045 * x_ref) + 0.7 * np.sin(0.012 * x_ref)
    dy_dx = 2.0 * 0.045 * np.cos(0.045 * x_ref) + 0.7 * 0.012 * np.cos(0.012 * x_ref)
    psi_ref = np.arctan(dy_dx)

    # approximate curvature and yaw-rate reference
    d2y_dx2 = -2.0 * 0.045**2 * np.sin(0.045 * x_ref) - 0.7 * 0.012**2 * np.sin(0.012 * x_ref)
    kappa = d2y_dx2 / max((1 + dy_dx**2)**1.5, 1e-6)
    r_ref = v_ref * kappa
    return x_ref, y_ref, psi_ref, r_ref, v_ref

def disturbance_profile(t, scenario):
    crosswind = 0.0
    yaw_moment = 0.0
    noise_sigma = 0.0

    if scenario == "crosswind":
        if 8.0 <= t <= 14.0:
            crosswind = 750.0
            yaw_moment = 120.0
    if scenario == "noise":
        noise_sigma = 0.025
    return crosswind, yaw_moment, noise_sigma
