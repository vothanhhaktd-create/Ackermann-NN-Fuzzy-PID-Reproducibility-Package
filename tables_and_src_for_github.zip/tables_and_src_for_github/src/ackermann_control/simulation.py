import time
import numpy as np
import pandas as pd

from .parameters import VehicleParams, ControllerParams, SimulationParams
from .vehicle_model import VehicleState, step_vehicle, wrap_angle
from .controllers import PIDController, FuzzyPIDController, NNFuzzyPIDController
from .mpc_benchmark import MPCBenchmark
from .scenarios import reference_path, disturbance_profile
from .metrics import compute_metrics

def tracking_errors(state, ref):
    x_ref, y_ref, psi_ref, r_ref, v_ref = ref
    dx = x_ref - state.x
    dy = y_ref - state.y
    ey = -np.sin(state.psi) * dx + np.cos(state.psi) * dy
    epsi = wrap_angle(state.psi - psi_ref)
    er = state.r - r_ref
    return ey, epsi, er

def make_controller(name, cp, seed=7):
    if name == "PID":
        return PIDController(cp)
    if name == "Fuzzy-PID":
        return FuzzyPIDController(cp)
    if name == "NN-Fuzzy-PID":
        return NNFuzzyPIDController(cp, seed=seed)
    if name == "MPC":
        return MPCBenchmark(cp)
    raise ValueError(f"Unknown controller: {name}")

def configure_vehicle_for_scenario(base_params, scenario, t):
    p = VehicleParams(**base_params.__dict__)
    if scenario == "low_friction":
        p.mu = 0.4
    elif scenario == "high_friction":
        p.mu = 0.9
    elif scenario == "mass_plus":
        p.m = base_params.m * 1.20
    elif scenario == "mass_minus":
        p.m = base_params.m * 0.80
    elif scenario == "stiffness_plus":
        p.Cf = base_params.Cf * 1.30
        p.Cr = base_params.Cr * 1.30
    elif scenario == "stiffness_minus":
        p.Cf = base_params.Cf * 0.70
        p.Cr = base_params.Cr * 0.70
    elif scenario == "speed_mass":
        if t >= 12:
            p.m = base_params.m * 1.25
        p.mu = 0.7
    return p

def run_single_simulation(controller_name="NN-Fuzzy-PID",
                          scenario="nominal",
                          vehicle_params=None,
                          controller_params=None,
                          sim_params=None):
    vehicle_params = vehicle_params or VehicleParams()
    controller_params = controller_params or ControllerParams()
    sim_params = sim_params or SimulationParams()
    rng = np.random.default_rng(sim_params.seed)

    controller = make_controller(controller_name, controller_params, seed=sim_params.seed)
    state = VehicleState(x=0, y=0.4, psi=np.deg2rad(2.0), vy=0.0, r=0.0, v=15.0)

    N = int(sim_params.T / sim_params.Ts)
    rows = []
    prev_delta = 0.0
    comp_times = []

    for k in range(N):
        t = k * sim_params.Ts
        ref = reference_path(t, scenario=scenario if scenario == "speed_mass" else "nominal")
        veh = configure_vehicle_for_scenario(vehicle_params, scenario, t)
        crosswind, yaw_moment, noise_sigma = disturbance_profile(t, scenario)

        ey, epsi, er = tracking_errors(state, ref)
        if noise_sigma > 0:
            ey += rng.normal(0, noise_sigma)
            epsi += rng.normal(0, noise_sigma * 0.25)
            er += rng.normal(0, noise_sigma * 0.10)

        tic = time.perf_counter()
        delta, info = controller.compute(ey, epsi, er, state.vy, state.r, state.v,
                                         sim_params.Ts, veh)
        comp_times.append((time.perf_counter() - tic) * 1000.0)

        state = step_vehicle(state, delta, ref[4], veh, sim_params.Ts,
                             crosswind_force=crosswind,
                             yaw_moment_disturbance=yaw_moment)

        delta_rate = (delta - prev_delta) / sim_params.Ts
        prev_delta = delta

        rows.append({
            "t": t,
            "x": state.x,
            "y": state.y,
            "psi": state.psi,
            "vy": state.vy,
            "r": state.r,
            "v": state.v,
            "x_ref": ref[0],
            "y_ref": ref[1],
            "psi_ref": ref[2],
            "r_ref": ref[3],
            "v_ref": ref[4],
            "ey": ey,
            "epsi": epsi,
            "er": er,
            "delta_rad": delta,
            "delta_deg": np.rad2deg(delta),
            "delta_rate_deg_s": np.rad2deg(delta_rate),
            "Kp": info.get("Kp", np.nan),
            "Ki": info.get("Ki", np.nan),
            "Kd": info.get("Kd", np.nan),
            "dKpN": info.get("dKpN", 0.0),
            "dKiN": info.get("dKiN", 0.0),
            "dKdN": info.get("dKdN", 0.0),
            "dKpF": info.get("dKpF", 0.0),
            "dKiF": info.get("dKiF", 0.0),
            "dKdF": info.get("dKdF", 0.0),
            "crosswind_N": crosswind,
            "mu": veh.mu,
            "mass_kg": veh.m,
            "Cf": veh.Cf,
            "Cr": veh.Cr,
        })

    df = pd.DataFrame(rows)
    metrics = compute_metrics(df)
    metrics["avg_computation_time_ms"] = float(np.mean(comp_times))
    metrics["max_computation_time_ms"] = float(np.max(comp_times))
    return df, metrics

def run_all_scenarios():
    controllers = ["PID", "Fuzzy-PID", "NN-Fuzzy-PID", "MPC"]
    scenarios = [
        "nominal",
        "crosswind",
        "low_friction",
        "high_friction",
        "speed_mass",
        "noise",
        "mass_plus",
        "mass_minus",
        "stiffness_plus",
        "stiffness_minus",
    ]
    all_data = {}
    all_metrics = {}
    for sc in scenarios:
        for ctrl in controllers:
            df, met = run_single_simulation(ctrl, sc)
            all_data[(sc, ctrl)] = df
            all_metrics[(sc, ctrl)] = met
    return all_data, all_metrics
