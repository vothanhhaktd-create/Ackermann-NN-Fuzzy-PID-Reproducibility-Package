from dataclasses import dataclass
import numpy as np
from .parameters import VehicleParams

@dataclass
class VehicleState:
    x: float = 0.0
    y: float = 0.0
    psi: float = 0.0
    vy: float = 0.0
    r: float = 0.0
    v: float = 15.0

def tyre_force_saturated(alpha, C, mu, Fz):
    """Linear tyre with smooth saturation.

    The function approximates sector-bounded tyre behaviour while remaining
    numerically simple and transparent.
    """
    Fy_lin = C * alpha
    Fy_max = mu * Fz
    return Fy_max * np.tanh(Fy_lin / max(Fy_max, 1e-6))

def step_vehicle(state: VehicleState,
                 delta: float,
                 v_cmd: float,
                 params: VehicleParams,
                 Ts: float,
                 crosswind_force: float = 0.0,
                 yaw_moment_disturbance: float = 0.0,
                 longitudinal_tau: float = 0.45) -> VehicleState:
    """One-step nonlinear bicycle/Ackermann vehicle propagation."""
    m, Iz, lf, lr = params.m, params.Iz, params.lf, params.lr
    v = max(state.v, params.v_min)

    # Simple longitudinal first-order speed evolution for scenario testing.
    v_dot = (v_cmd - state.v) / longitudinal_tau

    alpha_f = delta - np.arctan2(state.vy + lf * state.r, v)
    alpha_r = -np.arctan2(state.vy - lr * state.r, v)

    Fzf = m * params.g * lr / (lf + lr)
    Fzr = m * params.g * lf / (lf + lr)

    Fyf = tyre_force_saturated(alpha_f, params.Cf, params.mu, Fzf)
    Fyr = tyre_force_saturated(alpha_r, params.Cr, params.mu, Fzr)

    vy_dot = (Fyf + Fyr + crosswind_force) / m - v * state.r
    r_dot = (lf * Fyf - lr * Fyr + yaw_moment_disturbance) / Iz

    x_dot = state.v * np.cos(state.psi) - state.vy * np.sin(state.psi)
    y_dot = state.v * np.sin(state.psi) + state.vy * np.cos(state.psi)
    psi_dot = state.r

    return VehicleState(
        x=state.x + Ts * x_dot,
        y=state.y + Ts * y_dot,
        psi=state.psi + Ts * psi_dot,
        vy=state.vy + Ts * vy_dot,
        r=state.r + Ts * r_dot,
        v=state.v + Ts * v_dot
    )

def wrap_angle(angle):
    return (angle + np.pi) % (2 * np.pi) - np.pi
