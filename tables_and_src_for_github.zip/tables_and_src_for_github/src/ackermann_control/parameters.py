from dataclasses import dataclass
import numpy as np

@dataclass
class VehicleParams:
    m: float = 1200.0
    Iz: float = 1800.0
    lf: float = 1.25
    lr: float = 1.35
    L: float = 2.60
    Cf: float = 55000.0
    Cr: float = 60000.0
    delta_max: float = np.deg2rad(30.0)
    delta_rate_max: float = np.deg2rad(120.0)
    mu: float = 0.9
    g: float = 9.81
    v_min: float = 1.0

@dataclass
class ControllerParams:
    ky: float = 1.00
    kpsi: float = 1.50
    kr: float = 0.35

    Kp0: float = 0.85
    Ki0: float = 0.08
    Kd0: float = 0.18

    Gs: float = 2.50
    Gsdot: float = 0.80

    GKp: float = 0.25
    GKi: float = 0.03
    GKd: float = 0.06

    Kp_min: float = 0.40
    Kp_max: float = 1.40
    Ki_min: float = 0.00
    Ki_max: float = 0.18
    Kd_min: float = 0.05
    Kd_max: float = 0.35

    KpN_max: float = 0.15
    KiN_max: float = 0.02
    KdN_max: float = 0.04

    hidden_neurons: int = 10

    gamma_p: float = 0.05
    gamma_i: float = 0.01
    gamma_d: float = 0.02
    sigma_p: float = 0.02
    sigma_i: float = 0.02
    sigma_d: float = 0.02

    I_max: float = 1.50
    derivative_filter_tau: float = 0.05

@dataclass
class SimulationParams:
    Ts: float = 0.01
    T: float = 25.0
    seed: int = 7
