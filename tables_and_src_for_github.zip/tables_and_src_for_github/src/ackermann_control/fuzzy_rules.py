import numpy as np

LABELS = ["NB", "NS", "ZO", "PS", "PB"]
CENTERS = np.array([-1.0, -0.5, 0.0, 0.5, 1.0])

# Linguistic output values mapped to numerical correction levels.
OUTPUT_LEVEL = {
    "NB": -1.0,
    "NS": -0.5,
    "ZO": 0.0,
    "PS": 0.5,
    "PB": 1.0,
}

RULE_KP = [
    ["PB", "PB", "PS", "ZO", "ZO"],
    ["PB", "PS", "PS", "ZO", "NS"],
    ["PS", "PS", "ZO", "NS", "NS"],
    ["ZO", "ZO", "NS", "NS", "NB"],
    ["ZO", "NS", "NS", "NB", "NB"],
]

RULE_KI = [
    ["NS", "NS", "ZO", "PS", "PS"],
    ["NS", "ZO", "ZO", "PS", "PB"],
    ["ZO", "ZO", "PS", "ZO", "ZO"],
    ["PB", "PS", "ZO", "ZO", "NS"],
    ["PS", "PS", "ZO", "NS", "NS"],
]

RULE_KD = [
    ["PB", "PS", "PS", "ZO", "ZO"],
    ["PS", "PS", "ZO", "NS", "NS"],
    ["PS", "ZO", "ZO", "ZO", "NS"],
    ["NS", "NS", "ZO", "PS", "PS"],
    ["ZO", "ZO", "PS", "PS", "PB"],
]

def triangular_memberships(x):
    """Five triangular membership functions over [-1, 1]."""
    x = float(np.clip(x, -1.0, 1.0))
    widths = 0.5
    mu = np.maximum(1.0 - np.abs(x - CENTERS) / widths, 0.0)

    # Ensure nonzero coverage at boundaries.
    if x <= -1.0:
        mu[0] = 1.0
    if x >= 1.0:
        mu[-1] = 1.0
    return mu

def fuzzy_gain_corrections(s_norm, ds_norm):
    """Mamdani-style fuzzy inference with weighted-average defuzzification."""
    mu_s = triangular_memberships(s_norm)
    mu_ds = triangular_memberships(ds_norm)

    def infer(rule_table):
        numerator = 0.0
        denominator = 0.0
        for i in range(5):
            for j in range(5):
                w = mu_s[i] * mu_ds[j]
                numerator += w * OUTPUT_LEVEL[rule_table[i][j]]
                denominator += w
        return numerator / max(denominator, 1e-9)

    return infer(RULE_KP), infer(RULE_KI), infer(RULE_KD)
