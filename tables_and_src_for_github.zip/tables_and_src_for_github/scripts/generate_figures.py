import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from ackermann_control.simulation import run_all_scenarios
from ackermann_control.plotting import plot_path_comparison, plot_lateral_error, plot_steering, plot_gains

def main():
    fig_dir = ROOT / "results" / "figures"
    fig_dir.mkdir(parents=True, exist_ok=True)
    all_data, _ = run_all_scenarios()

    for scenario in ["nominal", "crosswind", "low_friction", "speed_mass", "noise"]:
        plot_path_comparison(all_data, scenario, fig_dir)
        plot_lateral_error(all_data, scenario, fig_dir)
        plot_steering(all_data, scenario, fig_dir)
        plot_gains(all_data, scenario, fig_dir)

    print(f"Figures saved to {fig_dir}")

if __name__ == "__main__":
    main()
