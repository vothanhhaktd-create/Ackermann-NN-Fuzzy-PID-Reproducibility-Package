import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import pandas as pd
from ackermann_control.simulation import run_all_scenarios
from ackermann_control.metrics import metrics_to_frame
from ackermann_control.plotting import (
    plot_path_comparison,
    plot_lateral_error,
    plot_steering,
    plot_gains,
)

def main():
    data_dir = ROOT / "data"
    fig_dir = ROOT / "results" / "figures"
    table_dir = ROOT / "results" / "tables"
    data_dir.mkdir(exist_ok=True)
    fig_dir.mkdir(parents=True, exist_ok=True)
    table_dir.mkdir(parents=True, exist_ok=True)

    all_data, all_metrics = run_all_scenarios()

    for (scenario, controller), df in all_data.items():
        safe_controller = controller.replace("-", "_")
        df.to_csv(data_dir / f"{scenario}_{safe_controller}.csv", index=False)

    metrics_df = metrics_to_frame(all_metrics)
    metrics_df.to_csv(table_dir / "overall_metrics.csv", index=False)
    metrics_df.to_excel(table_dir / "overall_metrics.xlsx", index=False)

    for scenario in ["nominal", "crosswind", "low_friction", "speed_mass", "noise"]:
        plot_path_comparison(all_data, scenario, fig_dir)
        plot_lateral_error(all_data, scenario, fig_dir)
        plot_steering(all_data, scenario, fig_dir)
        plot_gains(all_data, scenario, fig_dir)

    print("All simulations completed.")
    print(f"CSV data saved to: {data_dir}")
    print(f"Figures saved to: {fig_dir}")
    print(f"Tables saved to: {table_dir}")

if __name__ == "__main__":
    main()
