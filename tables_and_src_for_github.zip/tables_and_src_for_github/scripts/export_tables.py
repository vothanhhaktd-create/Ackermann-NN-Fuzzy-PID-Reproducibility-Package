import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from ackermann_control.simulation import run_all_scenarios
from ackermann_control.metrics import metrics_to_frame

def main():
    table_dir = ROOT / "results" / "tables"
    table_dir.mkdir(parents=True, exist_ok=True)
    _, all_metrics = run_all_scenarios()
    df = metrics_to_frame(all_metrics)
    df.to_csv(table_dir / "overall_metrics.csv", index=False)
    df.to_excel(table_dir / "overall_metrics.xlsx", index=False)
    print(f"Tables saved to {table_dir}")

if __name__ == "__main__":
    main()
