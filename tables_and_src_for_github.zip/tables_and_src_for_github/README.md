# Python Code for NN–Fuzzy–PID Steering Control of Ackermann Vehicles

This repository contains the full Python implementation for the manuscript:

**A Structured Neural-Supervised Fuzzy–PID Steering Controller with ISS Guarantees for Nonlinear Ackermann Vehicles**

## Included Python modules

```text
src/ackermann_control/
├── __init__.py
├── parameters.py
├── vehicle_model.py
├── fuzzy_rules.py
├── controllers.py
├── mpc_benchmark.py
├── scenarios.py
├── simulation.py
├── metrics.py
└── plotting.py

scripts/
├── run_all.py
├── generate_figures.py
└── export_tables.py
```

## Install

```bash
pip install -r requirements.txt
```

## Run all simulations

```bash
python scripts/run_all.py
```

## Outputs

```text
data/                  CSV simulation data
results/figures/        PNG figures
results/tables/         CSV/XLSX performance tables
```

## Notes

This Python code reproduces the control-oriented simulation framework:
- nonlinear Ackermann/bicycle model
- PID controller
- Fuzzy–PID controller
- proposed NN–Fuzzy–PID controller
- lightweight MPC benchmark
- robustness scenarios
- metrics and figure export

The high-fidelity Simscape Multibody model mentioned in the manuscript should be uploaded separately if available.
